/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  trailingSlash: true,
  images: { domains: ['cdn.example.com'] },
};
module.exports = nextConfig;
